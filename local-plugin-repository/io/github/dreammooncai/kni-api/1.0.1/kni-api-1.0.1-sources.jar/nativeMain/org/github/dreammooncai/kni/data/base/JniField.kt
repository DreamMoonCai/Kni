package org.github.dreammooncai.kni.data.base

import org.github.dreammooncai.kni.factory.FieldClass
import org.github.dreammooncai.kni.data.sign.KniFieldSign
import org.github.dreammooncai.kni.KniBridge
import kotlinx.cinterop.CPointer
import kotlinx.cinterop.ExperimentalForeignApi
import kotlinx.cinterop.cstr
import kotlinx.cinterop.invoke
import kotlinx.cinterop.memScoped
import org.github.dreammooncai.kni.data.KniField
import org.github.dreammooncai.kni.data.KniMethod
import platform.jni.JNIEnvVar
import platform.jni.jfieldID
import platform.jni.jobject

@OptIn(ExperimentalForeignApi::class)
abstract class JniField(bridge: KniBridge) : KniBridge(bridge) {
    protected abstract val jField: jobject
    protected open val jFieldID: jfieldID by lazy {
        memScoped {
            runJavaCatching {
                (if (isStatic) bridge.fGetStaticFieldID else bridge.fGetFieldID)(
                    bridge.env,
                    declaringClass.asClass,
                    name.cstr.ptr,
                    asSign.typeSign.cstr.ptr
                )
            }.getOrNull()
        } ?: error("无法在 ${declaringClass.name} 找到 $name 字段")
    }

    companion object {
        fun create(bridge: KniBridge, jField: jobject) = object : JniField(bridge) {
            override val jField: jobject = jField.ref
        }
    }

    fun asKni(thisRef: jobject) = KniField.create(this, jFieldID,this, thisRef)

    val asSign by lazy {
        KniFieldSign(this)
    }

    /**
     * The field name.
     * ----------------
     * 字段名。
     */
    val name by lazy {
        method("getName", "()Ljava/lang/String;", FieldClass.asClass, jField).string()
    }

    /**
     * The field declared class.
     * ----------------
     * 字段声明类。
     */
    open val declaringClass by lazy {
        method("getDeclaringClass", "()Ljava/lang/Class;", FieldClass.asClass, jField).call()!!.asKniClass
    }

    /**
     * The field type.
     * ----------------
     * 字段类型。
     */
    val type by lazy {
        method("getType", "()Ljava/lang/Class;", FieldClass.asClass, jField).call()!!.asKniClass
    }

    open val modifiers: Int by lazy {
        method(
            "getModifiers",
            "()I",
            FieldClass.asClass,
            jField
        ).int()
    }

    val isStatic by lazy {
        // java.lang.reflect.Modifier.STATIC = 0x0008
        (modifiers and 0x0008) != 0
    }

    override fun toString(): String {
        return "$asSign"
    }
}