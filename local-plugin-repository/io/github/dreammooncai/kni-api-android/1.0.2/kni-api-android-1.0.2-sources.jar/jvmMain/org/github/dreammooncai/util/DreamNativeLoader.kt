package org.github.dreammooncai.util

import java.nio.file.Files
import java.nio.file.StandardCopyOption
import kotlin.io.path.createTempFile

object DreamNativeLoader {

    private val loaded = HashSet<String>()
    private val lock = Any()

    @Suppress("UnsafeDynamicallyLoadedCode")
    fun loadLibrary(name: String) {

        synchronized(lock) {
            if (loaded.contains(name)) {
                return
            }
            loaded.add(name)
            runCatching {
                runCatching { System.loadLibrary(name) }.onFailure {

                    val libName = when {
                        isWindows() -> "$name.dll"
                        isMac() -> "lib$name.dylib"
                        else -> "lib$name.so"
                    }

                    val path = "/native/${getABI()}/$libName"
                    val stream = DreamNativeLoader::class.java.getResourceAsStream(path)
                        ?: error("Library not found in resources: $path and ${it.message}")

                    val temp = createTempFile("native-$name-", libName)
                    Files.copy(stream, temp, StandardCopyOption.REPLACE_EXISTING)
                    temp.toFile().deleteOnExit()

                    System.load(temp.toAbsolutePath().toString())
                }
            }.onFailure {
                loaded.remove(name)
                throw it
            }
        }
    }

    fun getABI(): String {
        val arch = System.getProperty("os.arch")?.lowercase() ?: return "x86_64"
        return when {
            arch in listOf("x86", "i386", "i486", "i586", "i686") -> "x86"
            arch in listOf("x86_64", "amd64") -> "x86_64"
            arch.startsWith("armv7") || arch == "arm" -> "armeabi-v7a"
            arch == "aarch64" || arch == "arm64" -> "arm64-v8a"
            else -> "x86_64"
        }
    }

    private fun isWindows() = System.getProperty("os.name")?.lowercase()?.contains("win") ?: false
    private fun isMac() = System.getProperty("os.name")?.lowercase()?.contains("mac") ?: false
}